<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<img src="<?php echo e(asset('storage/ktm/'.$photo->ktm)); ?>" alt="">
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html><?php /**PATH /home/ariffudin/Laravel/p/resources/views/admin/fotoKader/ktm.blade.php ENDPATH**/ ?>