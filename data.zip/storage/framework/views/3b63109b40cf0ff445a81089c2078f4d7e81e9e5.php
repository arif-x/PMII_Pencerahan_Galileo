

<?php $__env->startSection('content'); ?>

<!-- Button trigger modal -->
<div class="mt-5">
    <div class="container">
        <div style="margin-bottom: 50px;">
            <button type="button" class="btn btn-warning text-white" id="createArticle">
                <strong>Buat Artikel</strong>
            </button>
        </div>

        <div class="table-responsive">
            <table class="table stripe row-border order-column data-table mt-4">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Judul</th>
                        <th>Kategori</th>
                        <th>Keyword</th>
                        <th>Deskripsi</th>
                        <th width="150px">Atur</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>        
</div>


<div class="modal fade" id="ajaxModel" tabindex="-1" role="dialog" aria-labelledby="modelHeading" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modelHeading">Buat Artikel</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
              </button>
          </div>
          <div class="modal-body">
            <div class="row">
                <div class="col-md-12">
                    <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                    <?php endif; ?>

                    <form name="contentForm" id="contentForm">
                        <input type="hidden" name="artikel_id" id="artikel_id">

                        <div class="form-group">
                            <label for="">Judul</label>
                            <input type="text" name="title" id="title" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label for="">Keyword</label>
                            <input type="text" name="keyword" id="keyword" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label for="">Desckripsi</label>
                            <input type="text" name="description" id="description" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label for="">Kategori</label>
                            <input type="text" name="category" id="category" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label for="">Konten</label>
                            <textarea name="contents" id="contents" rows="50" required></textarea>
                        </div>
                        <button class="btn btn-primary btn-sm" id="saveBtn" style="width: 100%">Simpan</button>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>

<script src="https://cdn.ckeditor.com/4.13.1/standard/ckeditor.js"></script>

<script type="text/javascript">
    $(function () {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        var table = $('.data-table').DataTable({
            processing: true,
            serverSide: true,
            ajax: "<?php echo e(route('manage.index')); ?>",
            columns: [
            {data: 'DT_RowIndex', name: 'DT_RowIndex'},
            {data: 'title', name: 'title'},
            {data: 'category', name: 'category'},
            {data: 'keyword', name: 'keyword'},
            {data: 'description', name: 'description'},
            {data: 'action', name: 'action', orderable: false, searchable: false},
            ]
        });

        $('#createArticle').click(function () {
            $('#saveBtn').val("create-article");
            $('#artikel_id').val('');
            $('#contentForm').trigger("reset");
            $('#modelHeading').html("Tambah Artikel");
            $('#ajaxModel').modal('show');
        });

        $('body').on('click', '.editArticle', function () {
            var artikel_id = $(this).data('id');
            $.get("<?php echo e(route('manage.index')); ?>" +'/' + artikel_id +'/edit', function (data) {
                $('#modelHeading').html("Edit Artikel");
                $('#saveBtn').val("edit-artikel");
                $('#ajaxModel').modal('show');
                $('#artikel_id').val(data.id);
                $('#title').val(data.title);
                $('#keyword').val(data.keyword);
                $('#description').val(data.description);
                $('#category').val(data.category);
                CKEDITOR.instances['contents'].setData(data.content);                
                $('#contents').val(data.contents);
            })
        });

        $('#saveBtn').click(function (e) {
            e.preventDefault();
            $(this).html('Memproses..');

            for (instance in CKEDITOR.instances) {
                CKEDITOR.instances['contents'].updateElement();
            }

            $.ajax({
                data: $('#contentForm').serialize(),
                url: "<?php echo e(route('manage.store')); ?>",
                type: "POST",
                dataType: 'json',
                success: function (data) {
                    $('#contentForm').trigger("reset");
                    $('#ajaxModel').modal('hide');
                    table.draw();
                },
                error: function (data) {
                    console.log('Error:', data);
                    $('#saveBtn').html('Simpan');
                }
            });
        });
        $('body').on('click', '.deleteArticle', function () {
            var artikel_id = $(this).data("id");
            confirm("Are You sure want to delete !");
            $.ajax({
                type: "DELETE",
                url: "<?php echo e(route('manage.store')); ?>"+'/'+artikel_id,
                success: function (data) {
                    table.draw();
                },
                error: function (data) {
                    console.log('Error:', data);
                }
            });
        });
    });
</script>

<script>
    CKEDITOR.replace('contents', {        
        filebrowserImageBrowseUrl: '/filemanager?type=Images',
        filebrowserImageUploadUrl: '/filemanager/upload?type=Images&_token=',
        filebrowserBrowseUrl: '/filemanager?type=Files',
        filebrowserUploadUrl: '/filemanager/upload?type=Files&_token=',
        height: 500
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.cms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ariffudin/Laravel/p/resources/views/cms/index.blade.php ENDPATH**/ ?>