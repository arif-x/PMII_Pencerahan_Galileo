<?php $__env->startSection('content'); ?>      

<br>
<br>
<br>
<div class="container">
	<?php if($message = Session::get('info')): ?>
	<div class="col-md-12 alert alert-info alert-block margin-tengah">
		<button type="button" class="close" data-dismiss="alert">×</button>    
		<strong><?php echo e($message); ?></strong>
	</div>
	<?php endif; ?>
</div>

<div class="container bootstrap snippet">

	<div class="row">
		<div class="col-md-3" style="padding-top: 10px;">
			<div class="card my-card-border">
				<div class="card-header my-card-header">
					<?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<strong><?php echo e($g->name); ?></strong>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				<div class="card-body">
					<?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>					
					<form method="POST" action="<?php echo e(route('kader.profile.photo.store')); ?>" enctype="multipart/form-data">
						<?php echo csrf_field(); ?>

						<div class="col-md-12">
							<img src="<?php echo e(asset('storage/foto/'.$g->photo)); ?>" class="img-fluid mx-auto d-block border-radius-10px" alt="img1" name="asli">
						</div>
						<br>
						<strong>Status Kaderisasi: <?php echo e($g->status_kaderisasi); ?></strong>
						<br><br>
						<label for="file" class="col-form-label">
							<strong>Ganti Foto</strong>
						</label>
						<input type="file" id="file" name="image" class="form-control">

						<div class="mb-0">
							<div class="margin-tengah">
								<button type="submit" class="btn btn-primary" style="width: 100%;">Ganti</button>
							</div>
						</div>
					</form>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
				</div>
			</div>
		</div>

		<div class="col-md-9" style="padding-top: 10px;">
			<div class="card my-card-border">
				<div class="card-header my-card-header">
					<div class="panel-heading">
						<ul class="nav nav-tabs border-0">
							<li class="active card-header-padding"><a href="#profile" data-toggle="tab">Profil</a></li>
							<li class="card-header-padding">|</li>
							<li class="card-header-padding"><a href="#edit-biodata" data-toggle="tab">Edit Profil</a></li>
						</ul>
					</div>
				</div>
				<div class="card-body">
					<div class="col-md-12">
						<div class="tab-content">

							<div class="tab-pane in active" id="profile">			
								<form>
									<strong>
										<div class="form-group row">
											<label for="text" class="col-md-3 col-form-label">NIM</label>
											<div class="col-md-9">
												<input type="text" id="nim" class="form-control" value="<?php echo e(Auth::user()->nim); ?>" readonly>
											</div>
										</div>
										<div class="form-group row">
											<label for="text" class="col-md-3 col-form-label">Email</label>
											<div class="col-md-9">
												<input type="text" id="email" class="form-control" value="<?php echo e(Auth::user()->email); ?>" readonly>
											</div>
										</div>
										<div class="form-group row">
											<label for="text" class="col-md-3 col-form-label">Tanggal Lahir</label>
											<div class="col-md-9">
												<input type="text" class="form-control" value="<?php echo e(Auth::user()->tanggal_lahir); ?>" readonly>
											</div>
										</div>
										<div class="form-group row">
											<label for="text" class="col-md-3 col-form-label">Jenis Kelamin</label>
											<div class="col-md-9">
												<input type="text" id="jenis_kelamin" class="form-control" value="<?php echo e(Auth::user()->jenis_kelamin); ?>" readonly>
											</div>
										</div>
										<div class="form-group row">
											<label for="text" class="col-md-3 col-form-label">Jurusan</label>
											<div class="col-md-9">
												<input type="text" id="jurusan" class="form-control" value="<?php echo e(Auth::user()->jurusan); ?>" readonly>
											</div>
										</div>
										<div class="form-group row">
											<label for="text" class="col-md-3 col-form-label">Alamat Di Malang</label>
											<div class="col-md-9">
												<input type="text" id="alamat_di_malang" class="form-control" value="<?php echo e(Auth::user()->alamat_di_malang); ?>" readonly>
											</div>
										</div>
										<div class="form-group row">
											<label for="text" class="col-md-3 col-form-label">Alamat Asli</label>
											<div class="col-md-9">
												<input type="text" id="alamat_asli" class="form-control" value="<?php echo e(Auth::user()->alamat_asli); ?>" readonly>
											</div>
										</div>
										<div class="form-group row">
											<label for="text" class="col-md-3 col-form-label">Nama Ayah</label>
											<div class="col-md-9">
												<input type="text" id="nama_ayah" class="form-control" value="<?php echo e(Auth::user()->nama_ayah); ?>" readonly>
											</div>
										</div>
										<div class="form-group row">
											<label for="text" class="col-md-3 col-form-label">Nama Ibu</label>
											<div class="col-md-9">
												<input type="text" id="nama_ibu" class="form-control" value="<?php echo e(Auth::user()->nama_ibu); ?>" readonly>
											</div>
										</div>
										<div class="form-group row">
											<label for="text" class="col-md-3 col-form-label">Nomor HP</label>
											<div class="col-md-9">
												<input type="text" id="no_hp" class="form-control" value="<?php echo e(Auth::user()->no_hp); ?>" readonly>
											</div>
										</div>
										<div class="form-group row">
											<label for="text" class="col-md-3 col-form-label">Minat</label>
											<div class="col-md-9">
												<input type="text" id="minat" class="form-control" value="<?php echo e(Auth::user()->minat); ?>" readonly>
											</div>
										</div>
										<div class="form-group row">
											<label for="text" class="col-md-3 col-form-label">Bakat</label>
											<div class="col-md-9">
												<input type="text" id="bakat" class="form-control" value="<?php echo e(Auth::user()->bakat); ?>" readonly>
											</div>
										</div>
										<div class="form-group row">
											<label for="text" class="col-md-3 col-form-label">Alasan</label>
											<div class="col-md-9">
												<input type="text" id="alasan" class="form-control" value="<?php echo e(Auth::user()->alasan); ?>" readonly>
											</div>
										</div>
										<div class="form-group row">
											<label for="text" class="col-md-3 col-form-label">Target Ke Depan</label>
											<div class="col-md-9">
												<input type="text" id="target_ke_depan" class="form-control" value="<?php echo e(Auth::user()->target_ke_depan); ?>" readonly>
											</div>
										</div>
									</strong>
								</form>
							</div>

							<div class="tab-pane fade" id="edit-biodata">
								<form method="POST" action="<?php echo e(route('kader.profile.store')); ?>">
									<?php echo csrf_field(); ?>
									<strong>
										<div class="form-group row">
											<label for="text" class="col-md-3 col-form-label">NIM</label>
											<div class="col-md-9">
												<input type="text" id="nim" name="nim" class="form-control" value="<?php echo e(Auth::user()->nim); ?>">
											</div>
										</div>
										<div class="form-group row">
											<label for="text" class="col-md-3 col-form-label">Tanggal Lahir</label>
											<div class="col-md-9">
												<input type="date" name="tanggal_lahir" class="form-control" value="<?php echo e(Auth::user()->tanggal_lahir); ?>">
											</div>
										</div>
										<div class="form-group row">
											<label for="text" class="col-md-3 col-form-label">Jenis Kelamin</label>
											<div class="col-md-9">
												<select id="jenis_kelamin" class="form-control" name="jenis_kelamin">
													<option selected value="<?php echo e(Auth::user()->jenis_kelamin); ?>"><?php echo e(Auth::user()->jenis_kelamin); ?></option>
													<option value="Laki-Laki">Laki-Laki</option>
													<option value="Perempuan">Perempuan</option>
												</select>
											</div>
										</div>
										<div class="form-group row">
											<label for="text" class="col-md-3 col-form-label">Jurusan</label>
											<div class="col-md-9">
												<select id="jurusan" class="form-control" name="jurusan">
													<option selected value="<?php echo e(Auth::user()->jurusan); ?>"><?php echo e(Auth::user()->jurusan); ?></option>
													<option value="Biologi">Biologi</option>
													<option value="Fisika">Fisika</option>
													<option value="Kimia">Kimia</option>
													<option value="Matematika">Matematika</option>
													<option value="Teknik Arsitektur">Teknik Arsitektur</option>
													<option value="Teknik Informatika">Teknik Informatika</option>
													<option value="Perpustakaan & Ilmu Informasi">Perpustakaan & Ilmu Informasi</option>
												</select>
											</div>
										</div>
										<div class="form-group row">
											<label for="text" class="col-md-3 col-form-label">Alamat Di Malang</label>
											<div class="col-md-9">
												<input type="text" id="alamat_di_malang" name="alamat_di_malang" class="form-control" value="<?php echo e(Auth::user()->alamat_di_malang); ?>">
											</div>
										</div>
										<div class="form-group row">
											<label for="text" class="col-md-3 col-form-label">Alamat Asli</label>
											<div class="col-md-9">
												<input type="text" id="alamat_asli" name="alamat_asli" class="form-control" value="<?php echo e(Auth::user()->alamat_asli); ?>">
											</div>
										</div>
										<div class="form-group row">
											<label for="text" class="col-md-3 col-form-label">Nama Ayah</label>
											<div class="col-md-9">
												<input type="text" id="nama_ayah" name="nama_ayah" class="form-control" value="<?php echo e(Auth::user()->nama_ayah); ?>">
											</div>
										</div>
										<div class="form-group row">
											<label for="text" class="col-md-3 col-form-label">Nama Ibu</label>
											<div class="col-md-9">
												<input type="text" id="nama_ibu" name="nama_ibu" class="form-control" value="<?php echo e(Auth::user()->nama_ibu); ?>">
											</div>
										</div>
										<div class="form-group row">
											<label for="text" class="col-md-3 col-form-label">Nomor HP</label>
											<div class="col-md-9">
												<input type="text" id="no_hp" name="no_hp" class="form-control" value="<?php echo e(Auth::user()->no_hp); ?>">
											</div>
										</div>
										<div class="form-group row">
											<label for="text" class="col-md-3 col-form-label">Minat</label>
											<div class="col-md-9">
												<input type="text" id="minat" name="minat" class="form-control" value="<?php echo e(Auth::user()->minat); ?>">
											</div>
										</div>
										<div class="form-group row">
											<label for="text" class="col-md-3 col-form-label">Bakat</label>
											<div class="col-md-9">
												<input type="text" id="bakat" name="bakat" class="form-control" value="<?php echo e(Auth::user()->bakat); ?>">
											</div>
										</div>
										<div class="form-group row">
											<label for="text" class="col-md-3 col-form-label">Alasan</label>
											<div class="col-md-9">
												<input type="text" id="alasan" name="alasan" class="form-control" value="<?php echo e(Auth::user()->alasan); ?>">
											</div>
										</div>
										<div class="form-group row">
											<label for="text" class="col-md-3 col-form-label">Target Ke Depan</label>
											<div class="col-md-9">
												<input type="text" id="target_ke_depan" name="target_ke_depan" class="form-control" value="<?php echo e(Auth::user()->target_ke_depan); ?>">
											</div>
										</div>
									</strong>
									<div class="form-group row mb-0">
										<div class="margin-tengah">
											<button type="submit" class="btn btn-primary">
												Edit Profil
											</button>
										</div>
									</div>
								</form>
							</div>

						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ariffudin/Laravel/p/resources/views/kader/profile.blade.php ENDPATH**/ ?>