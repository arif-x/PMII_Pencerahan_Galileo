<?php

namespace App\Http\Controllers\Cms;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Cms;
use DataTables;

class CmsController extends Controller
{
	/**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
	public function index(Request $request){ 
		// $data = Cms::get();
		// dd($data);
		if ($request->ajax()) {
			$data = Cms::get();
			return Datatables::of($data)
			->addIndexColumn()
			->addColumn('action', function($row){
				$btn = '<a href="javascript:void(0)" data-toggle="tooltip"  data-id="'.$row->id.'" data-original-title="Edit" class="edit btn btn-primary btn-sm editArticle">Edit</a>';

				$btn = $btn.' <a href="javascript:void(0)" data-toggle="tooltip"  data-id="'.$row->id.'" data-original-title="Delete" class="btn btn-danger btn-sm deleteArticle">Delete</a>';

				return $btn;
			})
			->rawColumns(['action'])
			->make(true);
		}

		return view('cms.index');
	}

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request){
    	Cms::updateOrCreate(
            ['id' => $request->artikel_id],
    		[
                'title' => $request->title,
                'keyword' => $request->keyword,
                'description' => $request->description,
                'category' => $request->category,
                'content' => $request->contents
            ]
        );        

    	return response()->json(['success'=>'Artikel Disimpan.']);
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function edit($id){
    	$user = Cms::find($id);
    	return response()->json($user);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function destroy($id){
    	Cms::find($id)->delete();

    	return response()->json(['success'=>'Artikel Dihapus.']);
    }

    public function show($id){
        $user = Cms::find($id);
        return response()->json($user);   
    }
}
