<?php

namespace App\Http\Controllers\Kader;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\User;

class FriendController extends Controller
{
	public function index(){
		$user = User::paginate(5);
		return view('kader.friends', ['all' => $user]);
	}

	public function single($nim){
		$user = User::where('nim', $nim)->get();
		return view('kader.friendSingle', ['all ' => $user]);
	}

	public function search(Request $request){
		$nama = $request->nama;
		$angkatan_mapaba = $request->angkatan_mapaba;
		$user = User::where('name', 'Like', "%{$nama}%")
		->orWhere('angkatan', $angkatan_mapaba)
		->paginate(5);
		$error = "Not Found";
		if ($user->isEmpty()){			
			return view('kader.friendsError', compact('error'));
		}		
		return view('kader.friends', ['all' => $user]);
	}
}
