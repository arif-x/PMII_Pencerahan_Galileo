<?php

namespace App\Http\Controllers\Kader;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class DataVerifikasiController extends Controller
{
    public function index(){
    	return view('kader.verifikasi');
    }
}
