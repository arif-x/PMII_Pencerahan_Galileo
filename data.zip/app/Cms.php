<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cms extends Model
{
	protected $table = "articles";
    protected $guarded = [];
}
