<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	@foreach ($data as $photo)
	<img src="{{ asset('storage/foto/'.$photo->photo) }}" alt="">
	@endforeach
</body>
</html>