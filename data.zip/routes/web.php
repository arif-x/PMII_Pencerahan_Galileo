<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
	return view('home');
});
Route::get('/home', 'HomeController@index')->name('home');

Auth::routes();

Route::group([
	'middleware' => ['auth'],
	'namespace' => 'Kader',
], function(){
	Route::get('/isi-biodata', 'DataBiodataController@index')->name('kader.isi-biodata');
	Route::post('/isi-biodata/store', 'DataBiodataController@store')->name('kader.isi-biodata.store');
});

Route::group([
	'middleware' => ['auth', 'biodata'],
	'namespace' => 'Kader',
], function(){
	Route::get('/verifikasi', 'DataVerifikasiController@index')->name('kader.verifikasi');
	Route::get('/profile', 'ProfileController@index')->name('kader.profil');
	Route::post('/profile/store', 'ProfileController@store')->name('kader.profile.store');
	Route::post('/profile/photo/store', 'ProfileController@photoStore')->name('kader.profile.photo.store');		
});

Route::group([
	'middleware' => ['auth', 'biodata', 'mapaba'],
	'namespace' => 'Kader',
], function(){
	Route::get('/friends', 'FriendController@index')->name('kader.teman');
	Route::get('/friends/{nim}', 'FriendController@single')->name('kader.teman.single');
	Route::get('/friends/tool/search', 'FriendController@search')->name('kader.teman.search');
});

Route::group([
	'middleware' => ['auth', 'admin'],
	'namespace' => 'Admin',	
], function(){
	Route::get('/admin/index', 'HomeController@index');
	Route::resource('/admin/kader','KaderController');
	Route::get('/admin/kader/{nim}/photo/pasphoto', 'DataFotokaderController@pasPhoto')->name('admin.kader.photo.pasphoto');
	Route::get('/admin/kader/{nim}/photo/ktm', 'DataFotokaderController@ktm')->name('admin.kader.photo.ktm');
});

Route::group([
	'middleware' => ['auth', 'biodata', 'mapaba'],
	'prefix' => 'filemanager'
], function() {
	\UniSharp\LaravelFilemanager\Lfm::routes();
});

Route::group([
	'middleware' => ['auth', 'biodata', 'mapaba'],
	'namespace' => 'Cms',	
], function(){
	Route::resource('/cms/manage', 'CmsController');
});