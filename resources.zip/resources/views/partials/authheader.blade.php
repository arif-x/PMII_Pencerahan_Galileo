<div class="page-main-header">
    <div class="main-header-left">
        <div class="logo-wrapper">
            <div class="row">
                    <dir class="col-sm-4 text-center">
                        <img src="{{ URL::asset('logo.png') }}" class="image-light" alt="" style="max-width: 80%; height: auto;" />        
                    </dir>
                    <dir class="col-sm-8" style="vertical-align: middle; padding-left: 0px !important;">
                        <h3 style="font-weight: bold;">ADMIN</h3>
                        <h6 style="color: #808080;">PMII "Pencerahan" Galileo</h6>            
                    </dir>
                </div>
        </div>
    </div>
    <div class="main-header-right row">
        <div class="mobile-sidebar">
        </div>
        <div class="nav-right col">
            <ul class="nav-menus">
               
            </ul>
            <div class="d-lg-none mobile-toggle">
                <i class="icon-more"></i>
            </div>
        </div>
    </div>
</div>