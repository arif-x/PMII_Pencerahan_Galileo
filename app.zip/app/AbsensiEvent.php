<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AbsensiEvent extends Model
{
    protected $table = "absensi_event";
    protected $guarded = [];
}
