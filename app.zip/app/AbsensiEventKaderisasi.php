<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AbsensiEventKaderisasi extends Model
{
    protected $table = "absensi_event_kaderisasi";
    protected $guarded = [];
}
