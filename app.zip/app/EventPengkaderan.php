<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EventPengkaderan extends Model
{
    protected $table = 'event_pengkaderans';
    protected $guarded = [];
}
